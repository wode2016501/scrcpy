package android.content;

public interface IContentProvider {
    // android.content.IContentProvider is hidden, this is a fake one to expose the type to the project
}
